CREATE TABLE "iso3" ("index" TEXT,  "name" TEXT)
