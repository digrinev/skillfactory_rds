CREATE TABLE "currency" ("index" TEXT,  "name" TEXT)
