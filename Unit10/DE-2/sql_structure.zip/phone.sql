CREATE TABLE "phone" ("index" TEXT,  "name" TEXT)
