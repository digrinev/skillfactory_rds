CREATE TABLE "worldcitiespop" ("Country" TEXT,  "City" TEXT,  "AccentCity" TEXT,  "Region" TEXT,  "Population" REAL,  "Latitude" REAL,  "Longitude" REAL)
