CREATE TABLE "continent" ("index" TEXT,  "name" TEXT)
