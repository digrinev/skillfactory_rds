<template>
  <div>
    AdvancedElements View
  </div>
</template>

<script>
export default {
  name: 'advanced-elements',
  created () {

  }
}
</script>

<style>

</style>
