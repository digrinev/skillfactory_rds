<template>
  <div>
    <div v-show="uploadError" class="alert alert-danger" role="alert">
      Необходимо задать метку добавляемого класса (более 3 символов) и добавить фотографию!
    </div>
    <input type="text" v-model="label" class="form-control" placeholder="Идентификатор персоны">
    <p></p>
    <UploadImages uploadMsg="Загрузите изображения в базу данных" @changed="handleImages"/>
    <button class="btn btn-primary form-control" @click="enroll">Создать персону</button>
    <p></p>

    <div class="panel panel-default" v-show="storage.length > 0">
      <!-- Default panel contents -->
      <div class="panel-heading">Картотека</div>

      <!-- Table -->
      <table class="table">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Метка класса</th>
            <th scope="col">Фотография</th>
            <th scope="col">Действие</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(col, index) in storage" :key="col.label">
            <th scope="row">{{index + 1}}</th>
            <td>{{col.label}}</td>
            <td><a :href="staticPath + 'photos/' + col.photos[0]" target="_blank"><i class="fa fa-camera fa-2x" aria-hidden="true"></i></a></td>
            <td><button class="btn btn-danger" title="удалить" @click="removeItem(index)"><i class="fa fa-remove fa-2x"></i></button></td>
          </tr>         
        </tbody>
      </table>
    </div>

    <div v-show="addTask" class="alert alert-success alert-dismissible" role="alert">
      <button @click="addTask=false" type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      Создана задача добавления персоны {{label}} в базу данных! Это займет некоторое время.
    </div>
 
  </div>

</template>

<script>

import UploadImages from 'vue-upload-drop-images'
import apiPath from '../../lib/api'

import { post } from 'axios'

export default {
  name: 'General',
  data () {
    return {
      label: '',
      uploaded_files: [],
      storage: [],
      staticPath: '',
      addTask: false,
      uploadError: false
    }
  },
  methods: {
    handleImages (files) {
      this.uploaded_files = files
    },

    enroll () {
      if (this.uploaded_files.length > 0 && this.label.length > 3) {
        this.uploaded_files.forEach(element => {
          this.fileUpload(element, this.label).then((response) => {
          })
        })
        this.uploadError = false
        this.addTask = true
        this.uploaded_files = []
        this.label = ''
      } else {
        this.uploadError = true
      }
    },

    removeItem (index) {
      let label = this.storage[index].label
      this.storage.splice(index, 1)

      this.$http.post(apiPath.apiPath + 'storage/remove?label=' + label)
                        .then(response => (this.storage = response.data))
    },

    fileUpload (file, label) {
      const url = apiPath.apiPath + 'storage/add_task'
      const formData = new FormData()
      formData.append('photo', file)
      formData.append('label', label)
      const config = {
        headers: {
          'content-type': 'multipart/form-data'
        }
      }
      return post(url, formData, config)
    },

    getStorage () {
      this.$http.post(apiPath.apiPath + 'storage/list')
                        .then(response => (this.storage = response.data))
    }
  },

  created () {
    this.getStorage()
    var staticPath = window.location.origin + '/static/'
    this.staticPath = staticPath
  },

  components: {
    UploadImages
  }
}
</script>

<style>

.color-palette {
  height: 35px;
  line-height: 35px;
  text-align: center;
}

.color-palette-set {
  margin-bottom: 15px;
}

.color-palette span {
  display: none;
  font-size: 12px;
}

.color-palette:hover span {
  display: block;
}

.color-palette-box h4 {
  position: absolute;
  top: 100%;
  left: 25px;
  margin-top: -40px;
  color: rgba(255, 255, 255, 0.8);
  font-size: 12px;
  display: block;
  z-index: 7;
}

</style>
