<template>
  <div>
    Icons Page
  </div>
</template>

<script>
export default {
  name: 'Icons',
  created () {

  }
}
</script>
