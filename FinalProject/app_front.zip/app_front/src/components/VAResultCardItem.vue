<template>
    <div class="col-md-2">
        <div class="thumbnail">
        <div class="caption">
            <h3>{{item.label}}</h3>
            <br>{{item.conf}}%</br>
            <img :src="staticPath + 'photos/' + item.photo[0]" :title="item.label" class="img-responsive img-thumbnail">
        </div>
        </div>
    </div>
</template>

<script>

import apiPath from '../lib/api'

export default {
  name: 'va-result-card-item',
  props: ['item'],
  data () {
    return {
      url: apiPath.apiPath,
      staticPath: ''
    }
  },
  created () {
    var staticPath = window.location.origin + '/static/'
    this.staticPath = staticPath
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h1, h2 {
  font-weight: normal;
}

ul {
  list-style-type: none;
  padding: 0;
}

li {
  display: inline-block;
  margin: 0 10px;
}

a {
  color: #42b983;
}
</style>
