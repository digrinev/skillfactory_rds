<template>
  <div class="row">
    <va-result-card-item v-for="(item, index) in results" :key="index" :item=item />
  </div>
</template>

<script>

import VAResultCardItem from './VAResultCardItem.vue'

export default {
  name: 'va-result-card',
  props: ['results'],
  data () {
    return {
    }
  },
  components: {
    'va-result-card-item': VAResultCardItem
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h1, h2 {
  font-weight: normal;
}

ul {
  list-style-type: none;
  padding: 0;
}

li {
  display: inline-block;
  margin: 0 10px;
}

a {
  color: #42b983;
}
</style>
