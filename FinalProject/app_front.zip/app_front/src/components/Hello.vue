<template>
  <div class="hello">
    <UploadImages uploadMsg="Загрузите изображение для поиска" @changed="handleImages" :max="1"/>
    <button class="btn btn-primary form-control" @click="match">Поиск в базе данных</button>
    <p></p>
    {{matches}}
  </div>
</template>

<script>
import UploadImages from 'vue-upload-drop-images'
import { post } from 'axios'
import apiPath from '../lib/api'

export default {
  name: 'hello',
  data () {
    return {
      uploaded_files: [],
      matches: []
    }
  },
  methods: {
    match () {
      if (this.uploaded_files.length > 0) {
        this.uploaded_files.forEach(element => {
          this.fileUpload(element).then((response) => {
            this.matches = response.data
          })
        })
      }
    },
    fileUpload (file) {
      const url = apiPath.apiPath + 'storage/match'
      const formData = new FormData()
      formData.append('photo', file)
      const config = {
        headers: {
          'content-type': 'multipart/form-data'
        }
      }
      return post(url, formData, config)
    },
    handleImages (files) {
      this.uploaded_files = files
    },
    clickBtn () {
      this.loading = !this.loading
      setTimeout(() => {
        this.loading = !this.loading
      }, 1000)
    }
  },
  components: {
    UploadImages
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h1, h2 {
  font-weight: normal;
}

ul {
  list-style-type: none;
  padding: 0;
}

li {
  display: inline-block;
  margin: 0 10px;
}

a {
  color: #42b983;
}
</style>
